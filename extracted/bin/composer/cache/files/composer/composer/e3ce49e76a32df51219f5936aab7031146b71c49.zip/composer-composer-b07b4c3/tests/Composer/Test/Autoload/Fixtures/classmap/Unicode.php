<?php

namespace Unicode\↑;

class ↑{
}
