<?php

class Pearlike_Foo
{
    public static $loaded = true;
}
