<?php

namespace JsonSchema\Exception;

interface ExceptionInterface
{
}
